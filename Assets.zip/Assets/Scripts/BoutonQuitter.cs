using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoutonQuitter : MonoBehaviour
{
    public void QuitGame ()
    {
        Application.Quit();
    }
}
