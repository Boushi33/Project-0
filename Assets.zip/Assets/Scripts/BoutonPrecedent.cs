using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BoutonPrecedent : MonoBehaviour
{
	public void Precedent ()
	 {
		SceneManager.LoadScene("EcranTitre");
	 }
}
