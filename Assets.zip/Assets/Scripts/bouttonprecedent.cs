using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class bouttonprecedent : MonoBehaviour
{
    public void Precedent ()
    {
        SceneManager.LoadScene("EcranTitre");
    }
}
